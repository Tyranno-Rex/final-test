package com.example.demo.post;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PostPutDTO {
    private String id;
    private String title;
    private String content;
}
